# CryptoApp-CORE
A simple core for any blockchain-based or cryptocurrency-related applications.

This is solely for my school thesis and is not intended for production purposes.

Installation
---
- `git clone` this repository somewhere (Somewhere in your home directory is recommended)
- Install the package: `pip install -e <path-to-cloned-repo>` 
    ##### (If you prefer installing the package in a venv, `cd` to the venv's parent directory first)
- The package is now installed with the name `crypto_app_core`